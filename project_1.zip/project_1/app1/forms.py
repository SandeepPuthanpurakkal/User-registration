from django.forms import ModelForm
from . models import usertable

class usertableform(ModelForm):
    class Meta:
        model=usertable
        fields ='__all__'
