from django.urls import path

from project_1.urls import path
from. import views
urlpatterns=[path("path1",views.display, name="display"),
             path("about",views.aboutus, name="aboutus"),
             path("reg",views.userreg, name="userreg"),
             path("",views.index, name="index"),
             path("table",views.tablepg, name="tablepg"),
             path("path6/<id2>", views.delete, name="delete")]