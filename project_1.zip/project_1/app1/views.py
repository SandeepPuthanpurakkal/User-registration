from django.shortcuts import render, HttpResponse
from app1.forms import usertableform
from app1.models import usertable

# Create your views here.

def display(request):
    return render(request,"homepage.html")

def display1(request):
    return render(request,"simplpage.html")

def aboutus(request):
    return render(request,"aboutus.html")

def tablepg(request):
    a=usertable.objects.all()
    return render(request,"table.html",{"tablekey":a})

def index(request):
    return render(request,"index.html")

def userreg(request):
    a=usertableform()
    if request.method=="POST":
        z=usertableform(request.POST)
        if z.is_valid():
            z.save()
            return HttpResponse("Success")

    return render(request,"userregistration.html",{"datakey":a})

def delete(request,id2):
    a=usertable.objects.get(id=id2)
    a.delete()
    return HttpResponse("Sucessfully Deleted")